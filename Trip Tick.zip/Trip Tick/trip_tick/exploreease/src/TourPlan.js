import React from 'react';
import './TourPlan.css'; // Remember to create and style this CSS file as needed

const TourPlan = () => {
  // Mock data for tour details
const tourDetails = {
    title: 'Amazing Adventure Tour',
    about: 'Join us for an amazing adventure across beautiful landscapes and vibrant cities.',
    price: 1200,
    location: 'Multiple Locations',
    tourPlan: [
      { stop: 1, location: 'City A', description: 'Exploring the historical landmarks of City A.' },
      { stop: 2, location: 'City B', description: 'Visiting the bustling markets of City B.' },
      { stop: 3, location: 'City C', description: 'Hiking through the scenic trails of City C.' }
    ]
  };
  

  return (
    <div className="tour-detail2">
      <h2>{tourDetails.title}</h2>
      <p><strong>About:</strong> {tourDetails.about}</p>
      <p><strong>Price:</strong> ${tourDetails.price}</p>
      <p><strong>Location:</strong> {tourDetails.location}</p>
      <div className="tour-plan2">
        <h3>Tour Plan</h3>
        <div className="tour-plan-timeline2">
          {tourDetails.tourPlan.map((stop, index) => (
            <div key={index} className="tour-plan-step2">
              <div className="tour-plan-step-marker2"></div>
              <div className="tour-plan-step-content2">
                <h4>Stop {stop.stop}: {stop.location}</h4>
                <p>{stop.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TourPlan;
